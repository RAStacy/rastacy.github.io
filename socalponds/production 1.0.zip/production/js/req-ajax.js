$('#reqform').on('submit', function (e) {
    e.preventDefault();

    var $this = $(this),
        data = $this.serialize(),
        validationData = $this.data( 'bValidator' );

    if ( validationData && validationData.isValid() ) {
        $this.html('Thank you for your submission.');
        
        $.ajax({
            type: 'POST',
            url: "../../php/req-mailer.php",
            data: data,
            dataType: "html";
            }
        });
    }
});
